﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web3._7
{
    public interface IMessageSender
    {
        string Send();
    }
}